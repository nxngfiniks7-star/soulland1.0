package com.soulland.mod;

import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = SoulLand.MODID)
public class RegistryEvents {
    @SubscribeEvent
    public static void items(RegistryEvent.Register<Item> e) {
        for (Item i : ModItems.ALL) e.getRegistry().register(i);
    }

    @SubscribeEvent
    public static void entities(RegistryEvent.Register<EntityEntry> e) {
        e.getRegistry().register(EntityEntryBuilder.create().entity(EntityRingDrop.class)
                .id(new ResourceLocation(SoulLand.MODID, "ring_drop"), 0).name("soulland.ring_drop")
                .tracker(64, 10, true).build());
    }
}
