package com.soulland.mod;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumParticleTypes;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

/**
 * เรนเดอร์ทุกอย่างรวมกัน 2 ดรอว์คอลต่อเฟรม (ลดอาการกระตุก):
 * วงแหวนวิญญาณ, วิญญาณยุทธ์, อนิเมชันดูดซับ, สัตว์วิญญาณ และเอฟเฟกต์สกิล
 */
@Mod.EventBusSubscriber(value = Side.CLIENT, modid = SoulLand.MODID)
public class FxRender {
    private static final float[][] BODY = {{1F, 1F, 1F}, {1F, 0.85F, 0.1F}, {0.7F, 0.25F, 0.95F}, {0.02F, 0.02F, 0.03F}, {1F, 0.1F, 0.1F}};
    private static final float[][] GLOW = {{1F, 1F, 1F}, {1F, 0.8F, 0.2F}, {0.8F, 0.4F, 1F}, {0.35F, 0.35F, 0.42F}, {1F, 0.3F, 0.1F}};
    private static final float[] WOOD = {0.45F, 0.28F, 0.12F};
    private static final float[] STEEL = {0.62F, 0.66F, 0.78F};
    private static final float[] BLUE = {0.3F, 0.6F, 1F};
    private static final float[] CY_CORE = {0.2F, 0.82F, 0.95F};
    private static final float[] CY_GLOW = {0.3F, 0.9F, 1F};
    private static final float[] CY_LIGHT = {0.75F, 1F, 1F};
    private static final float[] CY_SPOT = {0F, 0.35F, 0.6F};
    private static final float[] VINE = {0.12F, 0.75F, 0.85F};
    private static final float[] STEM = {0.55F, 0.95F, 1F};
    private static final float[] ORB = {0.9F, 0.9F, 1F};
    private static final float[] SILVER = {0.8F, 0.92F, 1F};
    private static final float[] VOIDC = {0.5F, 0.9F, 1F};
    private static final float[] MIRC = {0.85F, 0.95F, 1F};

    private static BufferBuilder b;
    private static double ox, oy, oz;
    private static int pass;
    private static float fade = 1F;

    // ================= เหตุการณ์ =================
    @SubscribeEvent
    public static void world(RenderWorldLastEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        Entity cam = mc.getRenderViewEntity();
        if (mc.world == null || cam == null) return;
        boolean any = !ClientFx.LIST.isEmpty() || !ClientState.mobRings.isEmpty();
        if (!any) for (EntityPlayer p : mc.world.playerEntities) if (ClientState.visuals.containsKey(p.getUniqueID())) { any = true; break; }
        if (!any) return;
        float pt = e.getPartialTicks();
        ox = lx(cam, pt); oy = ly(cam, pt); oz = lz(cam, pt);

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableCull();
        GlStateManager.disableAlpha();
        GlStateManager.enableBlend();
        GlStateManager.depthMask(false);
        Tessellator ts = Tessellator.getInstance();
        for (pass = 0; pass < 2; pass++) {
            if (pass == 0) GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
            else GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            b = ts.getBuffer();
            b.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            try { collect(mc, pt, cam); } catch (RuntimeException ex) { /* ห้ามให้เกมล่ม */ }
            fade = 1F;
            ts.draw();
        }
        GlStateManager.depthMask(true);
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.enableAlpha();
        GlStateManager.enableCull();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1F, 1F, 1F, 1F);
        GlStateManager.popMatrix();
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.isGamePaused()) return;
        ClientFx.tick();
        for (EntityPlayer p : mc.world.playerEntities) {
            ClientState.Visual v = ClientState.visuals.get(p.getUniqueID());
            if (v == null || !v.released || v.soul == 0 || p.ticksExisted % 2 != 0) continue;
            mc.world.spawnParticle(v.soul == 2 ? EnumParticleTypes.END_ROD : EnumParticleTypes.SPELL_WITCH,
                    p.posX + (mc.world.rand.nextDouble() - 0.5) * 0.9, p.posY + mc.world.rand.nextDouble() * 1.9,
                    p.posZ + (mc.world.rand.nextDouble() - 0.5) * 0.9, 0.0, 0.05, 0.0);
        }
    }

    // ================= รวบรวมสิ่งที่ต้องวาด =================
    private static void collect(Minecraft mc, float pt, Entity view) {
        boolean first = mc.gameSettings.thirdPersonView == 0;
        for (EntityPlayer p : mc.world.playerEntities) {
            ClientState.Visual v = ClientState.visuals.get(p.getUniqueID());
            if (v == null) continue;
            double px = lx(p, pt), py = ly(p, pt), pz = lz(p, pt);
            float t = p.ticksExisted + pt;
            if (v.abTier >= 0) absorb(px, py, pz, v.abTier, v.abProgress / 100F, t);
            if (p == view && first) continue;
            if (v.released && v.soul != 0) {
                rings(px, py, pz, v.tiers, t);
                double yaw = Math.toRadians(p.prevRenderYawOffset + (p.renderYawOffset - p.prevRenderYawOffset) * pt);
                double fx = -Math.sin(yaw), fz = Math.cos(yaw);
                if ((v.soul & 2) != 0) plant(px - fz * 0.45 + fx * 0.5, py + 1.05, pz + fx * 0.45 + fz * 0.5, t);
                if ((v.soul & 1) != 0) hammer(px + fz * 0.9, py + 1.35 + 0.06 * Math.sin(t * 0.07), pz - fx * 0.9, t);
            }
        }
        List<Integer> dead = new ArrayList<>();
        for (Map.Entry<Integer, int[]> en : ClientState.mobRings.entrySet()) {
            Entity m = mc.world.getEntityByID(en.getKey());
            if (m == null) { dead.add(en.getKey()); continue; }
            if (!m.isEntityAlive()) continue;
            int tier = 0;
            for (int x : en.getValue()) tier = Math.max(tier, x);
            tier = Math.min(4, tier);
            double r = 0.4 + m.width * 0.7 + tier * 0.08;
            ringAt(lx(m, pt), ly(m, pt) + m.height * 0.5, lz(m, pt), r, tier, m.ticksExisted + pt, 0);
        }
        for (Integer id : dead) ClientState.mobRings.remove(id);
        for (ClientFx.Fx f : new ArrayList<>(ClientFx.LIST)) drawFx(mc, f, pt, view, first);
    }

    // ================= วงแหวน =================
    private static void rings(double px, double py, double pz, int[] tiers, float t) {
        for (int i = 0; i < tiers.length; i++) {
            double r = 0.55 + 0.02 * Math.sin(t * 0.1 + i);
            ringAt(px, py + 0.35 + i * 0.17, pz, r, tiers[i], t, i);
        }
    }

    private static void ringAt(double x, double y, double z, double r, int tier, float t, int i) {
        tier = Math.max(0, Math.min(4, tier));
        if (pass == 0) {
            ringTube(x, y, z, r, 0.03, BODY[tier], 0.95F);
        } else {
            ringTube(x, y, z, r, 0.085, GLOW[tier], 0.27F);
            for (int k = 0; k < 3; k++) {
                double an = t * 0.07 * (i % 2 == 0 ? 1 : -1) + k * 2.094 + i;
                double bx = x + Math.cos(an) * r, bz = z + Math.sin(an) * r;
                line(bx, y - 0.05, bz, bx, y + 0.05, bz, 0.035, GLOW[tier], 0.9F);
                line(bx - 0.05, y, bz, bx + 0.05, y, bz, 0.035, GLOW[tier], 0.9F);
            }
        }
    }

    private static void ringTube(double cx, double cy, double cz, double r, double w, float[] c, float a) {
        int n = 24;
        double h = 0.025;
        for (int i = 0; i < n; i++) {
            double a0 = i * 2 * Math.PI / n, a1 = (i + 1) * 2 * Math.PI / n;
            double c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1);
            double ri = r - w, ro = r + w;
            quad(cx + ri * c0, cy + h, cz + ri * s0, cx + ro * c0, cy + h, cz + ro * s0, cx + ro * c1, cy + h, cz + ro * s1, cx + ri * c1, cy + h, cz + ri * s1, c, a);
            quad(cx + ri * c0, cy - h, cz + ri * s0, cx + ro * c0, cy - h, cz + ro * s0, cx + ro * c1, cy - h, cz + ro * s1, cx + ri * c1, cy - h, cz + ri * s1, c, a);
            quad(cx + ro * c0, cy - h, cz + ro * s0, cx + ro * c1, cy - h, cz + ro * s1, cx + ro * c1, cy + h, cz + ro * s1, cx + ro * c0, cy + h, cz + ro * s0, c, a);
        }
    }

    /** อนิเมชันดูดซับ: วงแหวนหดเข้าหาตัวพร้อมลอยขึ้น มีลำแสงพุ่ง */
    private static void absorb(double px, double py, double pz, int tier, float pr, float t) {
        tier = Math.max(0, Math.min(4, tier));
        double r = 0.45 + 2.6 * (1 - pr), y = py + 0.1 + pr * 1.3;
        if (pass == 0) {
            ringTube(px, y, pz, r, 0.05, BODY[tier], 0.95F);
        } else {
            ringTube(px, y, pz, r, 0.12, GLOW[tier], 0.35F);
            for (int k = 0; k < 4; k++) {
                double an = t * 0.5 + k * Math.PI / 2;
                double bx = px + Math.cos(an) * r, bz = pz + Math.sin(an) * r;
                line(bx, y - 0.08, bz, bx, y + 0.08, bz, 0.05, GLOW[tier], 0.9F);
            }
            line(px, py, pz, px, py + 2.3, pz, 0.3, GLOW[tier], 0.06F + 0.3F * pr);
            if (pr > 0.92F) line(px, py, pz, px, py + 2.6, pz, 0.9, GLOW[tier], 0.35F);
        }
    }

    // ================= โมเดลวิญญาณยุทธ์ =================
    private static void hammer(double hx, double hy, double hz, float t) {
        double yaw = t * 0.026;
        if (pass == 0) {
            boxY(hx, hy, hz, 0.04, 0.6, 0.04, yaw, WOOD, 1F);
            boxY(hx, hy + 0.535, hz, 0.28, 0.185, 0.18, yaw, STEEL, 1F);
            boxY(hx, hy + 0.53, hz, 0.30, 0.03, 0.20, yaw, BLUE, 1F);
        } else {
            boxY(hx, hy, hz, 0.09, 0.62, 0.09, yaw, BLUE, 0.22F);
            boxY(hx, hy + 0.535, hz, 0.34, 0.24, 0.24, yaw, BLUE, 0.28F);
        }
    }

    private static double[] stem(double hx, double hy, double hz, double u, double sway) {
        return new double[]{hx + Math.sin(u * 2.4) * 0.06 + sway * u, hy + 0.05 + u * 0.8, hz + Math.cos(u * 1.8) * 0.03};
    }

    /** หญ้าสีเงินคราม: ต้นอ่อนเรืองแสงลอยเหนือฝ่ามือ (ตามภาพอ้างอิง) */
    private static void plant(double hx, double hy, double hz, float t) {
        double sway = Math.sin(t * 0.05) * 0.03;
        if (pass == 1) {
            line(hx - 0.22, hy + 0.05, hz, hx + 0.22, hy + 0.05, hz, 0.12, ORB, 0.5F);
            line(hx, hy - 0.17, hz, hx, hy + 0.27, hz, 0.12, ORB, 0.5F);
            line(hx, hy + 0.05, hz - 0.22, hx, hy + 0.05, hz + 0.22, 0.12, ORB, 0.5F);
        }
        double[] pv = {hx, hy, hz};
        for (int i = 1; i <= 8; i++) {
            double[] q = stem(hx, hy, hz, i / 8.0, sway);
            seg(pv[0], pv[1], pv[2], q[0], q[1], q[2], 0.014 * (1 - 0.5 * i / 8.0), STEM, CY_GLOW);
            pv = q;
        }
        double[][] lv = {{0.28, 0.4, 0.7, 0.30}, {0.42, 3.4, 0.8, 0.27}, {0.6, 5.6, 0.6, 0.25}, {0.78, 2.4, 0.5, 0.22},
                         {0.15, 1.6, 1.0, 0.18}, {0.2, 4.7, 0.95, 0.18}, {0.52, 1.0, 0.75, 0.17}, {0.92, 0.2, 0.4, 0.15}};
        for (int i = 0; i < lv.length; i++) {
            double[] s = stem(hx, hy, hz, lv[i][0], sway);
            double az = lv[i][1] + Math.sin(t * 0.05 + i) * 0.15, tl = lv[i][2];
            leaf(s[0], s[1], s[2], Math.cos(az) * Math.cos(tl), Math.sin(tl), Math.sin(az) * Math.cos(tl), lv[i][3], lv[i][3] * 0.4);
        }
        double[] a = stem(hx, hy, hz, 0.35, sway);
        curl(a[0], a[1], a[2], -1, 0.45, 0, 0.35, 2.2);
        double[] c = stem(hx, hy, hz, 1.0, sway);
        curl(c[0], c[1], c[2], 0.1, 0.9, 0, 0.12, 1.5);
    }

    private static void curl(double bx, double by, double bz, double dx, double dy, double dz, double len, double turns) {
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        double px = bx, py = by, pz = bz;
        for (int k = 1; k <= 10; k++) {
            double u = k / 10.0, rad = 0.05 * (1 - u), ang = u * turns * 2 * Math.PI;
            double x = bx + dx * u * len + Math.cos(ang) * rad, y = by + dy * u * len + Math.sin(ang) * rad, z = bz + dz * u * len;
            seg(px, py, pz, x, y, z, 0.008, STEM, CY_GLOW);
            px = x; py = y; pz = z;
        }
    }

    /** ใบไม้มีจุดลายแบบในภาพ */
    private static void leaf(double bx, double by, double bz, double dx, double dy, double dz, double len, double wid) {
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        double sx = -dz, sz = dx, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        if (pass == 0) {
            kite(bx, by, bz, dx, dy, dz, sx, 0, sz, len, wid, CY_CORE, 0.88F);
            kite(bx + dx * len * 0.05, by + dy * len * 0.05, bz + dz * len * 0.05, dx, dy, dz, sx, 0, sz, len * 0.8, wid * 0.55, CY_LIGHT, 0.5F);
            for (int k = 0; k < 3; k++) {
                double f = 0.28 + k * 0.2, off = (k % 2 == 0 ? 1 : -1) * wid * 0.25;
                kite(bx + dx * len * f + sx * off, by + dy * len * f, bz + dz * len * f + sz * off, dx, dy, dz, sx, 0, sz, len * 0.15, wid * 0.12, CY_SPOT, 0.9F);
            }
        } else {
            kite(bx, by, bz, dx, dy, dz, sx, 0, sz, len * 1.15, wid * 1.5, CY_GLOW, 0.22F);
        }
    }

    // ================= เอฟเฟกต์สกิล =================
    private static void drawFx(Minecraft mc, ClientFx.Fx f, float pt, Entity view, boolean first) {
        float age = f.age + pt, left = f.dur - age;
        fade = left < 8 ? Math.max(0F, left / 8F) : 1F;
        Entity en = f.ent >= 0 ? mc.world.getEntityByID(f.ent) : null;
        if (f.ent >= 0 && en == null) { fade = 1F; return; }
        if (en == view && first && f.type >= 6 && f.type <= 8) { fade = 1F; return; }
        switch (f.type) {
            case 1: wrap(f, en, age, pt); break;
            case 2: parasite(en, age, pt); break;
            case 3: web(f, age); break;
            case 4: cage(f, age); break;
            case 5: spear(f, age); break;
            case 6: voidFx(en, age, pt); break;
            case 7: trueForm(en, age, pt); break;
            case 8: mirror(en, age, pt); break;
            case 9: storm(f, age); break;
            default: break;
        }
        fade = 1F;
    }

    /** 1 พันธนาการ */
    private static void wrap(ClientFx.Fx f, Entity en, float age, float pt) {
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt), H = en.height, W = en.width;
        if (age < 10) {
            double g = age / 10.0;
            vine(f.x, f.y, f.z, f.x + (ex - f.x) * g, f.y + (ey + H * 0.5 - f.y) * g, f.z + (ez - f.z) * g, 0.03, 0.2, 1, age, true);
        }
        double g = Math.min(1.0, age / 14.0);
        for (int k = 0; k < 3; k++) {
            double[] pv = null;
            for (int j = 0; j <= 16; j++) {
                double u = j / 16.0 * g, y = ey + u * H, ang = u * 12.0 + k * 2.094 + age * 0.05, r = W * 0.5 + 0.14 + 0.03 * Math.sin(u * 20);
                double x = ex + Math.cos(ang) * r, z = ez + Math.sin(ang) * r;
                if (pv != null) seg(pv[0], pv[1], pv[2], x, y, z, 0.03, VINE, CY_GLOW);
                if (j % 4 == 2) leafSmall(x, y, z, Math.cos(ang), 0.5, Math.sin(ang), 0.14);
                pv = new double[]{x, y, z};
            }
        }
    }

    /** 2 ปรสิต: เถางอกออกจากร่างศัตรู */
    private static void parasite(Entity en, float age, float pt) {
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt), H = en.height, W = en.width;
        double g = Math.min(1.0, age / 20.0), pulse = 1 + 0.1 * Math.sin(age * 0.4);
        for (int k = 0; k < 8; k++) {
            double a = k * 1.085, by = ey + H * (0.15 + 0.7 * ((k * 37 % 10) / 10.0));
            double bx = ex + Math.cos(a) * W * 0.3, bz = ez + Math.sin(a) * W * 0.3;
            double len = (0.5 + 0.4 * ((k * 53 % 7) / 7.0)) * g * pulse * 2;
            double dx = Math.cos(a), dy = 0.55, dz = Math.sin(a), l = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double tx = bx + dx / l * len, ty = by + dy / l * len, tz = bz + dz / l * len;
            vine(bx, by, bz, tx, ty, tz, 0.035, 0.08, k, age, true);
            leafSmall(tx, ty, tz, dx, dy, dz, 0.24);
        }
    }

    /** 3 โซ่ตรวนใยแมงมุม */
    private static void web(ClientFx.Fx f, float age) {
        double g1 = Math.min(1.0, age / 10.0);
        double qx = f.x + (f.x2 - f.x) * g1, qy = f.y + (f.y2 - f.y) * g1, qz = f.z + (f.z2 - f.z) * g1;
        if (pass == 1) {
            line(qx - 0.2, qy, qz, qx + 0.2, qy, qz, 0.12, ORB, 0.5F);
            line(qx, qy - 0.2, qz, qx, qy + 0.2, qz, 0.12, ORB, 0.5F);
            line(qx, qy, qz - 0.2, qx, qy, qz + 0.2, 0.12, ORB, 0.5F);
        }
        vine(f.x, f.y, f.z, qx, qy, qz, 0.025, 0.1, 3, age, false);
        if (age < 10) return;
        double gr = Math.min(1.0, (age - 10) / 12.0);
        int n = 16;
        double[][] ends = new double[n][3];
        for (int k = 0; k < n; k++) {
            double yy = 1 - 2 * (k + 0.5) / n, rr = Math.sqrt(1 - yy * yy), ph = k * 2.39996;
            double L = 4.2 * gr;
            ends[k][0] = f.x2 + Math.cos(ph) * rr * L; ends[k][1] = f.y2 + yy * L; ends[k][2] = f.z2 + Math.sin(ph) * rr * L;
            vine(f.x2, f.y2, f.z2, ends[k][0], ends[k][1], ends[k][2], 0.03, 0.15, k, age, true);
        }
        for (int lv = 0; lv < 2; lv++) {
            double fr = lv == 0 ? 0.45 : 0.85;
            for (int k = 0; k < n; k++) {
                for (int o : new int[]{1, 3}) {
                    int k2 = (k + o) % n;
                    seg(f.x2 + (ends[k][0] - f.x2) * fr, f.y2 + (ends[k][1] - f.y2) * fr, f.z2 + (ends[k][2] - f.z2) * fr,
                        f.x2 + (ends[k2][0] - f.x2) * fr, f.y2 + (ends[k2][1] - f.y2) * fr, f.z2 + (ends[k2][2] - f.z2) * fr, 0.012, VINE, CY_GLOW);
                }
            }
        }
    }

    /** 4 กรงขังหญ้าเงินคราม */
    private static void cage(ClientFx.Fx f, float age) {
        double R = f.x2, H = f.y2, g = Math.min(1.0, age / 10.0);
        double r = R * (1.35 - 0.35 * g), hh = H * g;
        int n = 12;
        for (int k = 0; k < n; k++) {
            double a = k * 2 * Math.PI / n, ca = Math.cos(a), sa = Math.sin(a);
            double[] pv = null;
            for (int j = 0; j <= 8; j++) {
                double u = j / 8.0, y = f.y + u * hh, rr = r * Math.sqrt(1 - u * u * 0.92);
                double x = f.x + ca * rr, z = f.z + sa * rr;
                if (pv != null) seg(pv[0], pv[1], pv[2], x, y, z, 0.04, VINE, CY_GLOW);
                if (j == 3) leafSmall(x, y, z, ca, 0.3, sa, 0.16);
                pv = new double[]{x, y, z};
            }
        }
        for (double fr : new double[]{0.05, 0.3, 0.55, 0.8}) {
            double y = f.y + fr * hh, rr = r * Math.sqrt(1 - fr * fr * 0.92);
            double pxx = f.x + rr, pzz = f.z;
            for (int s = 1; s <= 20; s++) {
                double a = s * 2 * Math.PI / 20, x = f.x + Math.cos(a) * rr, z = f.z + Math.sin(a) * rr;
                seg(pxx, y, pzz, x, y, z, 0.03, VINE, CY_GLOW);
                pxx = x; pzz = z;
            }
        }
    }

    /** 5 หอกเงินคราม (โมเดลหอก) */
    private static void spear(ClientFx.Fx f, float age) {
        double g = Math.min(1.0, age / 8.0);
        double dx = f.x2 - f.x, dy = f.y2 - f.y, dz = f.z2 - f.z, L = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (L < 0.1) return;
        dx /= L; dy /= L; dz /= L;
        double tipx = f.x + (f.x2 - f.x) * g, tipy = f.y + (f.y2 - f.y) * g, tipz = f.z + (f.z2 - f.z) * g;
        double tx = tipx - dx * 1.7, ty = tipy - dy * 1.7, tz = tipz - dz * 1.7;
        double sx = -dz, sz = dx, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        double ux = dy * sz, uy = dz * sx - dx * sz, uz = -dy * sx;
        if (pass == 0) {
            line(tx, ty, tz, tipx - dx * 0.4, tipy - dy * 0.4, tipz - dz * 0.4, 0.022, SILVER, 1F);
            kite(tipx - dx * 0.45, tipy - dy * 0.45, tipz - dz * 0.45, dx, dy, dz, sx, 0, sz, 0.45, 0.08, CY_LIGHT, 1F);
            kite(tipx - dx * 0.45, tipy - dy * 0.45, tipz - dz * 0.45, dx, dy, dz, ux, uy, uz, 0.45, 0.08, CY_LIGHT, 1F);
            kite(tx + dx * 0.05, ty + dy * 0.05, tz + dz * 0.05, dx, dy, dz, sx, 0, sz, 0.25, 0.07, CY_CORE, 0.9F);
            kite(tx + dx * 0.05, ty + dy * 0.05, tz + dz * 0.05, dx, dy, dz, ux, uy, uz, 0.25, 0.07, CY_CORE, 0.9F);
        } else {
            line(tx, ty, tz, tipx, tipy, tipz, 0.09, CY_GLOW, 0.3F);
            kite(tipx - dx * 0.5, tipy - dy * 0.5, tipz - dz * 0.5, dx, dy, dz, sx, 0, sz, 0.6, 0.16, CY_GLOW, 0.3F);
            line(f.x, f.y, f.z, tx, ty, tz, 0.06, CY_GLOW, 0.12F);
        }
    }

    /** 6 ว่างเปล่า */
    private static void voidFx(Entity en, float age, float pt) {
        if (pass != 1) return;
        double cx = lx(en, pt), cy = ly(en, pt) + en.height * 0.5, cz = lz(en, pt);
        double R = 1.0 + 0.08 * Math.sin(age * 0.3);
        for (int axis = 0; axis < 3; axis++) {
            double px = 0, py = 0, pz = 0;
            for (int s = 0; s <= 20; s++) {
                double a = s * 2 * Math.PI / 20, u = Math.cos(a) * R, v = Math.sin(a) * R;
                double x = axis == 0 ? 0 : u, y = axis == 0 ? u : (axis == 1 ? 0 : v), z = axis == 0 ? v : (axis == 1 ? u : 0);
                if (axis == 1) { x = u; y = 0; z = v; }
                if (s > 0) line(cx + px, cy + py, cz + pz, cx + x, cy + y, cz + z, 0.02, VOIDC, 0.55F);
                px = x; py = y; pz = z;
            }
        }
    }

    /** 7 ร่างจริงเงินคราม */
    private static void trueForm(Entity en, float age, float pt) {
        double ex = lx(en, pt), ey = ly(en, pt), ez = lz(en, pt), H = en.height + 0.3;
        for (int k = 0; k < 4; k++) {
            double[] pv = null;
            for (int j = 0; j <= 20; j++) {
                double u = j / 20.0, y = ey + u * H, ang = u * 10 + k * 1.57 + age * 0.08, r = 0.42 + 0.05 * Math.sin(u * 15);
                double x = ex + Math.cos(ang) * r, z = ez + Math.sin(ang) * r;
                if (pv != null) seg(pv[0], pv[1], pv[2], x, y, z, 0.035, VINE, CY_GLOW);
                if (j % 5 == 2) leafSmall(x, y, z, Math.cos(ang), 0.6, Math.sin(ang), 0.18);
                pv = new double[]{x, y, z};
            }
        }
        double yaw = 0;
        if (en instanceof EntityLivingBase) {
            EntityLivingBase lb = (EntityLivingBase) en;
            yaw = Math.toRadians(lb.prevRenderYawOffset + (lb.renderYawOffset - lb.prevRenderYawOffset) * pt);
        }
        double fx = -Math.sin(yaw), fz = Math.cos(yaw), rx = -fz, rz = fx;
        for (int side = -1; side <= 1; side += 2) {
            for (int j = 0; j < 3; j++) {
                double dx = -fx * 0.6 + rx * side * 0.9, dz = -fz * 0.6 + rz * side * 0.9;
                double dy = 0.2 + 0.3 * j + 0.15 * Math.sin(age * 0.15 + j);
                leaf(ex - fx * 0.2, ey + 1.3, ez - fz * 0.2, dx, dy, dz, 0.9 - 0.15 * j, 0.3 - 0.04 * j);
            }
        }
        if (pass == 1) {
            line(ex - fx * 0.3 - 0.4, ey + 1.0, ez - fz * 0.3, ex - fx * 0.3 + 0.4, ey + 1.0, ez - fz * 0.3, 0.2, CY_GLOW, 0.3F);
            line(ex, ey, ez, ex, ey + 2.2, ez, 0.5, CY_GLOW, 0.06F);
        }
    }

    /** 8 ปีศาจเงินครามแห่งกระจกดับสูญ */
    private static void mirror(Entity en, float age, float pt) {
        double cx = lx(en, pt), cy = ly(en, pt), cz = lz(en, pt), inn = Math.min(1.0, age / 8.0);
        for (int layer = 0; layer < 2; layer++) {
            int n = layer == 0 ? 14 : 9;
            double R = (layer == 0 ? 2.4 : 1.4) * (1.6 - 0.6 * inn), sp = (layer == 0 ? 1 : -1) * age * 0.04;
            for (int k = 0; k < n; k++) {
                double a = k * 2 * Math.PI / n + sp, px = cx + Math.cos(a) * R, pz = cz + Math.sin(a) * R;
                double h = (layer == 0 ? 1.7 : 1.1) + 0.3 * Math.sin(k * 1.9), y0 = cy + 0.2 + 0.15 * Math.sin(age * 0.1 + k);
                double tx = -Math.sin(a) * 0.28, tz = Math.cos(a) * 0.28;
                if (pass == 1) quad(px - tx, y0, pz - tz, px + tx, y0, pz + tz, px + tx, y0 + h, pz + tz, px - tx, y0 + h, pz - tz, MIRC, 0.14F);
                seg(px - tx, y0, pz - tz, px + tx, y0, pz + tz, 0.012, MIRC, MIRC);
                seg(px + tx, y0, pz + tz, px + tx, y0 + h, pz + tz, 0.012, MIRC, MIRC);
                seg(px + tx, y0 + h, pz + tz, px - tx, y0 + h, pz - tz, 0.012, MIRC, MIRC);
                seg(px - tx, y0 + h, pz - tz, px - tx, y0, pz - tz, 0.012, MIRC, MIRC);
                seg(px - tx, y0 + h * 0.2, pz - tz, px + tx, y0 + h * 0.8, pz + tz, 0.01, MIRC, MIRC);
            }
        }
    }

    /** 9 จิตฟ้ามรกตเงินคราม: พายุเถาวัลย์ */
    private static void storm(ClientFx.Fx f, float age) {
        double g = Math.min(1.0, age / f.dur);
        double cx = f.x + (f.x2 - f.x) * g, cy = f.y + (f.y2 - f.y) * g, cz = f.z + (f.z2 - f.z) * g;
        for (int L = 0; L < 12; L++) {
            double h = L * 0.34, r = 0.35 + L * 0.26;
            int n = 8;
            double[] pv = null;
            for (int k = 0; k <= n; k++) {
                double a = age * (0.45 + L * 0.02) + L * 0.55 + k * 6.283 / n;
                double x = cx + Math.cos(a) * r, z = cz + Math.sin(a) * r, y = cy + h;
                if (k < n) {
                    if (pass == 0) kite(x, y, z, -Math.sin(a), 0.25, Math.cos(a), 0, 1, 0, 0.55, 0.12, CY_CORE, 0.85F);
                    else kite(x, y, z, -Math.sin(a), 0.25, Math.cos(a), 0, 1, 0, 0.7, 0.2, CY_GLOW, 0.25F);
                }
                if (pv != null && pass == 1) line(pv[0], pv[1], pv[2], x, y, z, 0.01, CY_GLOW, 0.2F);
                pv = new double[]{x, y, z};
            }
        }
        if (pass == 1) line(cx, cy, cz, cx, cy + 4.2, cz, 0.7, CY_GLOW, 0.07F);
    }

    // ================= ตัวช่วยวาด =================
    private static double lx(Entity e, float pt) { return e.lastTickPosX + (e.posX - e.lastTickPosX) * pt; }
    private static double ly(Entity e, float pt) { return e.lastTickPosY + (e.posY - e.lastTickPosY) * pt; }
    private static double lz(Entity e, float pt) { return e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * pt; }

    private static void vtx(double x, double y, double z, float[] c, float a) {
        float al = a * fade;
        b.pos(x - ox, y - oy, z - oz).color(c[0], c[1], c[2], al > 1F ? 1F : al).endVertex();
    }

    private static void quad(double x1, double y1, double z1, double x2, double y2, double z2, double x3, double y3, double z3,
                             double x4, double y4, double z4, float[] c, float a) {
        vtx(x1, y1, z1, c, a); vtx(x2, y2, z2, c, a); vtx(x3, y3, z3, c, a); vtx(x4, y4, z4, c, a);
    }

    private static void line(double x1, double y1, double z1, double x2, double y2, double z2, double w, float[] c, float a) {
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1, len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6) return;
        dx /= len; dy /= len; dz /= len;
        double sx = -dz, sy = 0, sz = dx, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        double tx = dy * sz - dz * sy, ty = dz * sx - dx * sz, tz = dx * sy - dy * sx;
        sx *= w; sy *= w; sz *= w; tx *= w; ty *= w; tz *= w;
        quad(x1 - sx, y1 - sy, z1 - sz, x1 + sx, y1 + sy, z1 + sz, x2 + sx, y2 + sy, z2 + sz, x2 - sx, y2 - sy, z2 - sz, c, a);
        quad(x1 - tx, y1 - ty, z1 - tz, x1 + tx, y1 + ty, z1 + tz, x2 + tx, y2 + ty, z2 + tz, x2 - tx, y2 - ty, z2 - tz, c, a);
    }

    /** เส้นเถา: รอบแกนทึบ (pass 0) + แสงเรืองกว้าง (pass 1) */
    private static void seg(double x1, double y1, double z1, double x2, double y2, double z2, double w, float[] core, float[] glow) {
        if (pass == 0) line(x1, y1, z1, x2, y2, z2, w, core, 0.9F);
        else line(x1, y1, z1, x2, y2, z2, w * 2.6, glow, 0.22F);
    }

    private static void kite(double bx, double by, double bz, double dx, double dy, double dz, double sx, double sy, double sz,
                             double len, double wid, float[] c, float a) {
        double mx = bx + dx * len * 0.4, my = by + dy * len * 0.4, mz = bz + dz * len * 0.4;
        quad(bx, by, bz, mx + sx * wid, my + sy * wid, mz + sz * wid, bx + dx * len, by + dy * len, bz + dz * len,
             mx - sx * wid, my - sy * wid, mz - sz * wid, c, a);
    }

    private static void leafSmall(double x, double y, double z, double dx, double dy, double dz, double len) {
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= l; dy /= l; dz /= l;
        double sx = -dz, sz = dx, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        if (pass == 0) kite(x, y, z, dx, dy, dz, sx, 0, sz, len, len * 0.35, CY_CORE, 0.9F);
        else kite(x, y, z, dx, dy, dz, sx, 0, sz, len * 1.4, len * 0.6, CY_GLOW, 0.2F);
    }

    /** เถาวัลย์โค้งงอ */
    private static void vine(double x1, double y1, double z1, double x2, double y2, double z2, double w, double wob, int seed, float t, boolean leaves) {
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1, len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.05) return;
        double ux = dx / len, uy = dy / len, uz = dz / len;
        double sx = -uz, sy = 0, sz = ux, sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) { sx = 1; sz = 0; } else { sx /= sl; sz /= sl; }
        double tx = uy * sz - uz * sy, ty = uz * sx - ux * sz, tz = ux * sy - uy * sx;
        int n = Math.max(4, Math.min(14, (int) (len * 3.5)));
        double px = x1, py = y1, pz = z1;
        for (int i = 1; i <= n; i++) {
            double u = i / (double) n, env = Math.sin(u * Math.PI);
            double o1 = Math.sin(u * 9 + seed * 1.7 + t * 0.08) * wob * env, o2 = Math.cos(u * 7 + seed * 2.3 + t * 0.06) * wob * env;
            double qx = x1 + dx * u + sx * o1 + tx * o2, qy = y1 + dy * u + sy * o1 + ty * o2, qz = z1 + dz * u + sz * o1 + tz * o2;
            seg(px, py, pz, qx, qy, qz, w * (1 - 0.5 * u), VINE, CY_GLOW);
            if (leaves && i % 3 == 1) { double a = seed + i * 2.1; leafSmall(qx, qy, qz, Math.cos(a), 0.5, Math.sin(a), 0.14); }
            px = qx; py = qy; pz = qz;
        }
    }

    private static void boxY(double cx, double cy, double cz, double hx, double hy, double hz, double yaw, float[] c, float a) {
        double co = Math.cos(yaw), si = Math.sin(yaw);
        double[][] p = new double[8][3];
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? -hx : hx, y = (i & 2) == 0 ? -hy : hy, z = (i & 4) == 0 ? -hz : hz;
            p[i][0] = cx + x * co - z * si; p[i][1] = cy + y; p[i][2] = cz + x * si + z * co;
        }
        int[][] f = {{0, 1, 3, 2}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 3, 7, 5}};
        for (int[] q : f)
            quad(p[q[0]][0], p[q[0]][1], p[q[0]][2], p[q[1]][0], p[q[1]][1], p[q[1]][2],
                 p[q[2]][0], p[q[2]][1], p[q[2]][2], p[q[3]][0], p[q[3]][1], p[q[3]][2], c, a);
    }
}
