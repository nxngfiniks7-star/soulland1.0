package com.soulland.mod;

import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

/** วงแหวนวิญญาณที่ดรอปบนพื้น: เก็บเข้ากระเป๋าไม่ได้ ต้องคลิกซ้ายเพื่อดูดซับ */
public class EntityRingDrop extends EntityItem {
    public EntityRingDrop(World w) { super(w); }

    public EntityRingDrop(World w, double x, double y, double z, ItemStack s) { super(w, x, y, z, s); }

    @Override public void onCollideWithPlayer(EntityPlayer p) {}

    @Override public boolean canBeCollidedWith() { return true; }

    @Override public float getCollisionBorderSize() { return 0.5F; }

    @Override
    public void onUpdate() {
        super.onUpdate();
        if (world.isRemote && ticksExisted % 3 == 0 && getItem().getItem() instanceof ItemSoulRing) {
            int tier = ((ItemSoulRing) getItem().getItem()).tier;
            EnumParticleTypes t = tier == 0 ? EnumParticleTypes.END_ROD : tier == 1 ? EnumParticleTypes.FLAME
                    : tier == 2 ? EnumParticleTypes.SPELL_WITCH : tier == 3 ? EnumParticleTypes.SMOKE_LARGE : EnumParticleTypes.REDSTONE;
            world.spawnParticle(t, posX + (rand.nextDouble() - 0.5) * 0.4, posY + 0.3 + rand.nextDouble() * 0.5,
                    posZ + (rand.nextDouble() - 0.5) * 0.4, 0.0, 0.02, 0.0);
        }
    }
}
