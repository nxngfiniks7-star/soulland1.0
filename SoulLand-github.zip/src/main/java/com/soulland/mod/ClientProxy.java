package com.soulland.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderEntityItem;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        ClientRegistry.registerKeyBinding(ClientHandler.CAST);
        ClientRegistry.registerKeyBinding(ClientHandler.CYCLE);
        ClientRegistry.registerKeyBinding(ClientHandler.RELEASE);
        RenderingRegistry.registerEntityRenderingHandler(EntityRingDrop.class,
                m -> new RenderEntityItem(m, Minecraft.getMinecraft().getRenderItem()));
    }
}
