package com.soulland.mod;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;

/** ลูกแก้วปลุกวิญญาณยุทธ์ */
public class ItemSoulOrb extends Item {
    public ItemSoulOrb() { setMaxStackSize(16); }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World w, EntityPlayer p, EnumHand h) {
        ItemStack s = p.getHeldItem(h);
        if (!w.isRemote) {
            EntityPlayerMP mp = (EntityPlayerMP) p;
            if (SoulData.getSoul(mp) != 0) {
                mp.sendStatusMessage(new TextComponentTranslation("msg.soulland.already"), true);
                return new ActionResult<>(EnumActionResult.FAIL, s);
            }
            int soul = SoulData.rollSoul(w.rand, 0);
            SoulData.awaken(mp, soul);
            mp.sendMessage(new TextComponentTranslation("msg.soulland.awaken", new TextComponentTranslation("soul.soulland." + soul)));
            if (soul == 3) mp.sendMessage(new TextComponentTranslation("msg.soulland.twin"));
            if (!p.capabilities.isCreativeMode) s.shrink(1);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, s);
    }
}
