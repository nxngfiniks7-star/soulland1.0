package com.soulland.mod;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.WorldServer;

/** ระบบดูดซับวงแหวนวิญญาณ (ใช้เวลา 4 วินาที ระหว่างนั้นตัวละครขยับไม่ได้) */
public class Absorb {
    public static final int DURATION = 80;

    private static final EnumParticleTypes[] PARTS = {
        EnumParticleTypes.END_ROD, EnumParticleTypes.FLAME, EnumParticleTypes.SPELL_WITCH,
        EnumParticleTypes.SMOKE_LARGE, EnumParticleTypes.REDSTONE };

    public static boolean active(EntityPlayerMP p) { return SoulData.tag(p).getBoolean("abOn"); }

    private static void err(EntityPlayerMP p, String k) { p.sendStatusMessage(new TextComponentTranslation(k), true); }

    public static boolean start(EntityPlayerMP p, int tier) {
        if (active(p)) return false;
        int rings = SoulData.getRings(p);
        if (SoulData.getSoul(p) == 0) { err(p, "msg.soulland.needawaken"); return false; }
        if (rings >= 9) { err(p, "msg.soulland.maxrings"); return false; }
        if (SoulData.getLevel(p) < 10 * (rings + 1)) { err(p, "msg.soulland.needlevel"); return false; }
        NBTTagCompound t = SoulData.tag(p);
        t.setBoolean("abOn", true);
        t.setInteger("abTick", 0);
        t.setInteger("abTier", tier);
        SoulData.syncVisual(p);
        return true;
    }

    public static void tick(EntityPlayerMP p) {
        NBTTagCompound t = SoulData.tag(p);
        if (p.getHealth() <= 0 || p.isDead) { t.setBoolean("abOn", false); SoulData.syncVisual(p); return; }
        int tick = t.getInteger("abTick") + 1;
        int tier = Math.max(0, Math.min(4, t.getInteger("abTier")));
        t.setInteger("abTick", tick);
        p.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 5, 6, false, false));

        WorldServer ws = (WorldServer) p.world;
        float pr = tick / (float) DURATION;
        double radius = 0.4 + 2.8 * (1 - pr);
        double y = p.posY + 0.1 + pr * 1.3;
        for (int i = 0; i < 4; i++) {
            double a = tick * 0.35 + i * Math.PI / 2;
            ws.spawnParticle(PARTS[tier], p.posX + Math.cos(a) * radius, y, p.posZ + Math.sin(a) * radius, 1, 0, 0, 0, 0.0);
        }
        ws.spawnParticle(EnumParticleTypes.END_ROD, p.posX, p.posY + 0.2 + pr * 1.6, p.posZ, 1, 0.2, 0.3, 0.2, 0.01);
        if (tick % 20 == 0)
            ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.PLAYERS, 1.0F, 0.6F + pr);
        if (tick % 2 == 0) SoulData.syncVisual(p);
        if (tick >= DURATION) finish(p, tier);
    }

    private static void finish(EntityPlayerMP p, int tier) {
        NBTTagCompound t = SoulData.tag(p);
        t.setBoolean("abOn", false);
        t.setInteger("abTick", 0);
        WorldServer ws = (WorldServer) p.world;
        int rings = SoulData.getRings(p);
        int maxTier = Math.min(4, rings / 2 + 1);
        if (tier > maxTier) {
            p.attackEntityFrom(DamageSource.MAGIC, 14.0F);
            p.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 200, 0));
            p.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 400, 1));
            ws.spawnParticle(EnumParticleTypes.SMOKE_LARGE, p.posX, p.posY + 1, p.posZ, 40, 0.5, 0.8, 0.5, 0.05);
            p.sendMessage(new TextComponentTranslation("msg.soulland.ringfail"));
            SoulData.syncVisual(p);
            return;
        }
        SoulData.addTier(p, tier);
        SoulData.setRings(p, rings + 1);
        SoulData.applyBonuses(p);
        SoulData.setMana(p, SoulData.maxMana(p));
        int soul = SoulData.getSoul(p);
        if (!SoulSkills.available(soul, rings, SoulData.getSelected(p))) {
            int n = SoulSkills.next(soul, rings + 1, SoulData.getSelected(p));
            if (n >= 0) SoulData.setSelected(p, n);
        }
        ws.spawnParticle(EnumParticleTypes.END_ROD, p.posX, p.posY + 1, p.posZ, 80, 0.7, 0.9, 0.7, 0.15);
        ws.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, p.posX, p.posY + 1, p.posZ, 2, 0.3, 0.3, 0.3, 0.0);
        ws.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6F, 1.6F);
        SoulData.sync(p);
        SoulData.syncVisual(p);
        p.sendMessage(new TextComponentTranslation("msg.soulland.ringok", String.valueOf(rings + 1)));
    }
}
