package com.soulland.mod;

import net.minecraft.item.ItemSword;

/** ค้อนฮ่าวเทียน */
public class ItemHammer extends ItemSword {
    public ItemHammer(ToolMaterial m) { super(m); }
}
