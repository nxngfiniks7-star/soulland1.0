package com.soulland.mod;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = SoulLand.MODID)
public class ClientHandler {
    public static final KeyBinding CAST = new KeyBinding("key.soulland.cast", Keyboard.KEY_R, "key.categories.soulland");
    public static final KeyBinding CYCLE = new KeyBinding("key.soulland.cycle", Keyboard.KEY_V, "key.categories.soulland");
    public static final KeyBinding RELEASE = new KeyBinding("key.soulland.release", Keyboard.KEY_G, "key.categories.soulland");

    @SubscribeEvent
    public static void models(ModelRegistryEvent e) {
        for (Item i : ModItems.ALL)
            ModelLoader.setCustomModelResourceLocation(i, 0, new ModelResourceLocation(i.getRegistryName(), "inventory"));
    }

    @SubscribeEvent
    public static void keys(InputEvent.KeyInputEvent e) {
        while (CAST.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(0));
        while (CYCLE.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(1));
        while (RELEASE.isPressed()) NetworkHandler.CHANNEL.sendToServer(new PacketAction(2));
    }

    @SubscribeEvent
    public static void hud(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (ClientState.soul == 0 || mc.gameSettings.showDebugInfo || mc.player == null) return;
        FontRenderer fr = mc.fontRenderer;
        int soul = ClientState.soul;
        int accent = soul == 1 ? 0xFFFFAA33 : soul == 2 ? 0xFF55DDFF : 0xFFFF77FF;
        int x = 6, y = 6, w = 132, h = 96;
        int bw = w - 6;

        Gui.drawRect(x - 3, y - 3, x + w, y + h, 0xA0000000);
        Gui.drawRect(x - 3, y - 3, x + w, y - 1, accent);

        // วิญญาณยุทธ์
        fr.drawStringWithShadow(I18n.format("soul.soulland.hud." + soul), x, y, accent & 0xFFFFFF);

        // เลเวล (ตัวใหญ่)
        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y + 11, 0);
        GlStateManager.scale(2.0F, 2.0F, 1.0F);
        fr.drawStringWithShadow("Lv." + ClientState.level, 0, 0, 0xFFFFFF);
        GlStateManager.popMatrix();

        // แถบเลือด
        float hp = mc.player.getHealth(), mhp = Math.max(1F, mc.player.getMaxHealth());
        Gui.drawRect(x, y + 31, x + bw, y + 41, 0xFF1A1A1A);
        Gui.drawRect(x, y + 31, x + Math.min(bw, (int) (bw * Math.min(1F, hp / mhp))), y + 41, 0xFFDD2222);
        fr.drawStringWithShadow(I18n.format("hud.soulland.hp") + " " + (int) Math.ceil(hp) + "/" + (int) Math.ceil(mhp), x + 3, y + 32, 0xFFFFFF);

        // พลังวิญญาณ
        int max = 20 + ClientState.level * 6;
        Gui.drawRect(x, y + 44, x + bw, y + 54, 0xFF1A1A1A);
        Gui.drawRect(x, y + 44, x + Math.min(bw, bw * ClientState.mana / Math.max(1, max)), y + 54, 0xFF2E9BFF);
        fr.drawStringWithShadow(ClientState.mana + "/" + max, x + 3, y + 45, 0xFFFFFF);

        // EXP
        int cap = Math.min(99, 10 * (ClientState.rings + 1));
        boolean stuck = ClientState.level >= cap;
        int need = SoulData.expNeeded(ClientState.level);
        Gui.drawRect(x, y + 57, x + bw, y + 61, 0xFF1A1A1A);
        int ew = stuck ? bw : Math.min(bw, bw * ClientState.exp / Math.max(1, need));
        Gui.drawRect(x, y + 57, x + ew, y + 61, stuck ? 0xFFFF8800 : 0xFF55DD55);

        // ทักษะวิญญาณที่ N + ชื่อสกิล
        if (SoulSkills.available(ClientState.soul, ClientState.rings, ClientState.selected)) {
            SoulSkills.Skill sk = SoulSkills.ALL[ClientState.selected];
            fr.drawStringWithShadow(I18n.format("hud.soulland.skillnum", String.valueOf(sk.ring)), x, y + 65, 0xFFDD55);
            fr.drawStringWithShadow(I18n.format("skill.soulland." + sk.key), x, y + 75, 0xFFFFFF);
        } else {
            fr.drawStringWithShadow(I18n.format("hud.soulland.noskill"), x, y + 65, 0xAAAAAA);
        }
        if (stuck && cap < 99) fr.drawStringWithShadow(I18n.format("hud.soulland.bottleneck"), x, y + 85, 0xFF8800);
    }
}
